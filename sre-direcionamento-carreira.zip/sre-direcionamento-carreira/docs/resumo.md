# Resumo — Direcionamento para SRE

**Perfil resumido:**  
- 25 anos em infraestrutura; foco em entender sistemas  
- Prefere lidar com pessoas e dados  
- Disponibilidade: 2h/semana  
- Interesse: infraestrutura, nuvem, segurança  
- Experiências: gestão, ITIL/ISO, compliance, observabilidade  
- Objetivo: crescer na função atual

**Ranking de carreiras:**  
1) Arquiteto de Soluções (Cloud/Infra) — 19/20  
2) Segurança da Informação — 17/20  
3) **SRE** — 16/20 → **Escolhida**

**Próximo passo (Agent 2):**  
Criar plano de estudos SRE alinhado a 2h/semana, priorizando: SLOs/SLIs, observabilidade orientada a erro, gestão de incidentes, automação (scripts/IaC), práticas de confiabilidade em cloud e segurança em produção.
