
# Síntese das Habilidades (a partir do mapeamento do usuário)

**Entrada do usuário:**
- O que as pessoas elogiam: empatia, simpatia, criatividade para tecer narrativas, paciência para ensinar.
- Confiança em: montar narrativas e incluir pessoas em narrativas.
- Tipo de ajuda: orientação em tarefas difíceis e conselhos sobre planejamento pessoal.
- Faz com facilidade: criar histórias.
- Conteúdo consumido: RPG, jogos, filmes e séries.

## Habilidades Identificadas
### Habilidades Socioemocionais
- Empatia, simpatia, paciência, escuta ativa, acolhimento.

### Comunicação
- Storytelling (forte), escrita criativa, explicação por analogias, engajamento por narrativas.

### Ensino e Suporte
- Didática, mentoria, orientação em tarefas complexas, planejamento pessoal.

### Criatividade
- Criação de histórias, imaginação ativa, worldbuilding, criatividade aplicada à solução de problemas.

### Cognitivas/Organizacionais
- Organização de ideias, clareza ao estruturar informações, pensamento estratégico (reforçado por RPG/jogos).

## Aplicações Práticas
- Apresentações e comunicação interna, treinamentos narrativos, facilitação de grupos, mediação empática, criação de conteúdo e campanhas.
