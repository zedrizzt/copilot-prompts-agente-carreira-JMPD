# Roadmap SRE — 180 dias (2h/semana)

Este repositório contém um **plano completo e prático** para evolução na carreira de **SRE (Site Reliability Engineering)** com disponibilidade de **2h por semana**. Inclui visão do dia a dia, mapa de skills, roadmap estendido de 90 → **180 dias**, projeto de portfólio, roteiro de entrevistas e trilha de estudos.

> Objetivo: **crescer na função atual** de SRE, com foco em **pessoas** (primário) e **dados** (secundário), aproveitando experiências em **gestão, ITIL/ISO, compliance e observabilidade**.

---

## 📦 Conteúdo

- `README.md` — visão geral, plano completo e instruções.
- `ROADMAP_180_CHECKLIST.md` — checklist semanal pronto para uso.
- `docs/checklist_sre_180dias.pdf` — checklist em PDF (pronto para download/compartilhamento).

---

## 🧩 Visão do Dia a Dia (SRE)

- Definir e revisar **SLOs/SLIs** com os times, priorizando impacto no cliente.
- **Gerenciar incidentes** (comunicação, coordenação, pós-mortem sem culpa).
- Automatizar **operações repetitivas** e reduzir toil (runbooks, scripts, pipelines).
- **Instrumentar observabilidade** (logs, métricas, traces) com alertas saudáveis.
- **Segurança desde o design** (hardening, mínimo privilégio, conformidade), com foco em resiliência.

---

## 🧠 Mapa de Skills

**Core (essenciais):**
- SRE Fundamentals: SLO/SLI, error budget, trade-off confiabilidade vs. velocidade.
- Incident Management: comunicação, MTTR, postmortems eficazes.
- Observabilidade: RED/USE, logs estruturados, tracing distribuído, saúde de alertas.

**Nice-to-have (complementares):**
- Cloud & Plataformas: redes básicas, balanceamento, storage; um provedor (AWS/Azure/GCP).
- Automação & IaC: Git, bash/python, Terraform, CI/CD.

**Ferramentas & Tecnologias:**
- Observabilidade: Prometheus, Grafana, OpenTelemetry, ELK.
- Cloud & Orquestração: AWS/Azure/GCP, Kubernetes (conceitos), Terraform (básico).
- Confiabilidade & Incidentes: SLO tooling (Nobl9/Sloth), runbooks, gestão de incidentes.

---

## 📅 Roadmap de 180 dias (2h/semana)

> Estratégia: microblocos de 25–30 min; **aprender → fazer → documentar**; 1 entrega por semana.

### Mês 1 — Fundamentos de SRE + Mapeamento de Serviços
- Semana 1: Ler SLI/SLO (SRE Book) e anotar 5 insights.
- Semana 2: Identificar 1 serviço crítico; mapear usuários, dependências e falhas.
- Semana 3: Definir 2–3 SLIs e formas de medição.
- Semana 4: Definir SLO inicial (metas + janela) e criar “SLO v0.1”.

### Mês 2 — Observabilidade Essencial e Alertas
- Semana 5: Estudar RED/USE; selecionar métricas aplicáveis.
- Semana 6: Levantar métricas existentes; identificar gaps.
- Semana 7: Criar painel inicial (latência, erros, tráfego).
- Semana 8: Revisar alertas; remover 1 alerta ruidoso.

### Mês 3 — Gestão de Incidentes + Runbooks
- Semana 9: Boas práticas e papéis (IC, Scribe, Comms).
- Semana 10: Checklist de War Room e ensaio do fluxo.
- Semana 11: Template de postmortem sem culpa.
- Semana 12: Simular incidente e preencher postmortem.

### Mês 4 — Automação, Git e Redução de Toil
- Semana 13: Escolher um toil e medir impacto.
- Semana 14: Criar automação (bash/python) — MVP.
- Semana 15: README + versionamento no Git.
- Semana 16: Agendar execução (cron/job/CI) e medir ganhos.

### Mês 5 — SLO Dashboard, Error Budget e Governança
- Semana 17: Painel de SLO no Grafana (ou similar).
- Semana 18: Cálculo do error budget e política de uso.
- Semana 19: Política de revisão mensal de SLOs.
- Semana 20: Revisão geral e documento “SLO v1.0”.

### Mês 6 — Portfólio Interno + Consolidação
- Semana 21: Runbook de incidentes consolidado.
- Semana 22: Integração (SLO + Dashboard + Alertas + Automação).
- Semana 23: Portfólio interno (SLOs, dashboard, regras, runbooks, automação, postmortem).
- Semana 24: Slide deck e apresentação para liderança/equipe.

---

## 🚀 Projeto de Portfólio

**Projeto:** SLOs na Prática + Gestão de Incidentes com Observabilidade

**Escopo:**
- SLOs definidos, dashboard com SLIs, alertas atrelados a SLO, runbook de incidentes, template de postmortem e uma automação simples.

**Entregáveis:**
- Documento SLO/SLI; dashboard (prints/JSON); regras de alertas; runbook; template de postmortem; repositório com automação.

**Critérios de aceitação:**
- SLOs mensuráveis e rastreáveis ao objetivo do usuário.
- Alertas não ruidosos, com ação clara e owner definido.
- Postmortem sem culpa, com lições e follow-ups com prazos.

**Dica:** Use experiência de ITIL/ISO e compliance para ligar SLOs à gestão de risco e auditoria.

---

## 💬 Roteiro de Entrevistas (Júnior)

1. **SLI, SLO e Error Budget** — exemplo prático e política de congelamento quando orçamento é consumido.
2. **Incidentes críticos** — fluxo (detectar/triagem/mitigação/comunicação/postmortem) e redução de MTTR.
3. **Eliminação de toil** — automação e impacto em horas economizadas.
4. **Velocidade vs. Confiabilidade** — governança via error budget; canary e rollback.
5. **Métricas** — RED/USE e métricas de negócio.

---

## 🎓 Trilha DIO recomendada

- Buscar por **“SRE”, “DevOps”, “Observabilidade”, “Cloud”** em [dio.me](https://www.dio.me/).
- Seguir em paralelo ao roadmap (1–2 aulas por sessão de estudo).

---

## 📄 Checklist

O checklist completo (24 semanas) está em: [`ROADMAP_180_CHECKLIST.md`](./ROADMAP_180_CHECKLIST.md) e em PDF em [`docs/checklist_sre_180dias.pdf`](./docs/checklist_sre_180dias.pdf).

---

## 📥 Como usar no GitHub

1. Faça o fork/clone deste repositório modelo.
2. Ajuste os arquivos para o seu contexto (serviços, SLIs/SLOs, ferramentas).
3. Suba seu **dashboard JSON**, **regras de alerta** e **scripts** na pasta `assets/`.
4. Use **Issues** para registrar postmortems e ações de follow-up.
5. Use **Projects** (Kanban) para gerenciar as entregas semanais.

---

## 📜 Licença

Este conteúdo é disponibilizado sob **MIT License**. Adapte livremente e cite a fonte quando útil.
