# ✅ Checklist — Roadmap SRE (180 dias / 2h por semana)

## 📍 MÊS 1 — Fundamentos de SRE + Mapeamento de Serviços

### SEMANA 1
- [ ] Ler capítulos sobre SLI/SLO do SRE Book (resumo ou vídeo)
- [ ] Anotar 5 insights aplicáveis

### SEMANA 2
- [ ] Identificar 1 serviço crítico
- [ ] Mapear usuários, dependências e pontos de falha

### SEMANA 3
- [ ] Definir 2–3 SLIs (latência, erros, disponibilidade)
- [ ] Especificar como medir cada SLI

### SEMANA 4
- [ ] Definir SLO inicial (metas + janela)
- [ ] Criar documento “SLO v0.1”

---

## 📍 MÊS 2 — Observabilidade Essencial e Alertas

### SEMANA 5
- [ ] Estudar RED e USE
- [ ] Identificar métricas aplicáveis

### SEMANA 6
- [ ] Levantar métricas existentes
- [ ] Identificar lacunas de observabilidade

### SEMANA 7
- [ ] Criar painel simples (latência, erros, tráfego)
- [ ] Registrar prints/JSON do dashboard

### SEMANA 8
- [ ] Revisar alertas
- [ ] Eliminar pelo menos 1 alerta ruidoso e documentar

---

## 📍 MÊS 3 — Gestão de Incidentes + Runbooks

### SEMANA 9
- [ ] Estudar boas práticas de incidentes
- [ ] Criar guia de papéis: IC, Scribe, Comms

### SEMANA 10
- [ ] Criar checklist de War Room
- [ ] Ensaiar processo de condução de incidente

### SEMANA 11
- [ ] Criar template de postmortem sem culpa
- [ ] Incluir seções: impacto, causas, ações

### SEMANA 12
- [ ] Simular 1 incidente
- [ ] Preencher postmortem baseado na simulação

---

## 📍 MÊS 4 — Automação, Git e Redução de Toil

### SEMANA 13
- [ ] Identificar uma tarefa repetitiva (toil)
- [ ] Estimar impacto/tempo gasto atual

### SEMANA 14
- [ ] Criar rascunho de automação (bash/python)
- [ ] Entregar versão mínima funcional

### SEMANA 15
- [ ] Criar README explicando a automação
- [ ] Versionar no Git

### SEMANA 16
- [ ] Agendar execução (cron/job/CI)
- [ ] Medir redução de esforço após automação

---

## 📍 MÊS 5 — SLO Dashboard, Error Budget e Governança

### SEMANA 17
- [ ] Criar painel de SLO no Grafana (ou equivalente)
- [ ] Incluir SLI, SLO e janela de cálculo

### SEMANA 18
- [ ] Implementar cálculo de error budget
- [ ] Criar política de uso e alertas de risco

### SEMANA 19
- [ ] Criar política de revisão mensal de SLOs
- [ ] Definir critérios para ajuste ou rollback

### SEMANA 20
- [ ] Revisar SLO/SLI com base em dados coletados
- [ ] Criar documento oficial “SLO v1.0”

---

## 📍 MÊS 6 — Portfólio Interno + Consolidação

### SEMANA 21
- [ ] Consolidar runbook de incidentes completo
- [ ] Garantir clareza e acionabilidade

### SEMANA 22
- [ ] Integrar: SLOs, Dashboard, Alertas e Automação
- [ ] Verificar coerência final

### SEMANA 23
- [ ] Criar portfólio interno com entregáveis:
  - [ ] Documento SLO
  - [ ] Dashboard
  - [ ] Regras de alerta
  - [ ] Runbooks
  - [ ] Automação
  - [ ] Postmortem

### SEMANA 24
- [ ] Criar apresentação (slide deck) dos resultados
- [ ] Apresentar para liderança/equipe
- [ ] Planejar próximos 6 meses
